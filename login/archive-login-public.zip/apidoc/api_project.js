define({
  "name": "Cherrymenu",
  "version": "0.0.0",
  "description": "Api of Cherrymenu",
  "title": "Cherrymenu API",
  "url": "https://www.cherrymenu.com/login/",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-11-15T11:13:50.637Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
