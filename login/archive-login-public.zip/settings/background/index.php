<!DOCTYPE html>
<html lang="en">
  <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Kode is a Premium Bootstrap Admin Template, It's responsive, clean coded and mobile friendly">
  <meta name="keywords" content="bootstrap, admin, dashboard, flat admin template, responsive," />
  <title>Access Denide</title>

  <!-- ========== Css Files ========== -->
  <link href="../../../assets/Backend/css/root.css" rel="stylesheet">
  <style type="text/css">
    body{background: #F5F5F5;}
  </style>
  </head>
  <body>
        <div class="error-pages">
        <h1>403 Forbidden</h1>
        <h4>Directory access is forbidden.</h4>
        <div class="bottom-links">
          <a href="javascript:history.back()" class="btn btn-default">Go Back</a>
          <a href="../../../" class="btn btn-light">Go Homepage</a>
        </div>
</body>
</html>